# SNI Documentation (Starter Kit)

_Last updated: 2025-08-18 • Owner: Max (PO) • Maintainers: Claude Code, Agent_

This `/docs` folder is docs-as-code. Keep entries short and uniform.
