# Quality Gates

_Last updated: 2025-08-18 • Status: draft • Owner: Max (PO) / Claude Code (Engineer) • Repo: SNI_

- Min size 3; silhouette ≥0.50; snippet coverage ≥2.
