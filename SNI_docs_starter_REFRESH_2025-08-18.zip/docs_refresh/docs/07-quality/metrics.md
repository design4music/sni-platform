# Metrics

_Last updated: 2025-08-18 • Status: draft • Owner: Max (PO) / Claude Code (Engineer) • Repo: SNI_

- Coverage, Purity, Orphan rate, Cohesion.
