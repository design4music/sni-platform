# Schema & ERD

_Last updated: 2025-08-18 • Status: draft • Owner: Max (PO) / Claude Code (Engineer) • Repo: SNI_

- articles, keywords, keyword_canon_map, article_keywords, article_clusters, cluster_digests.
