# article_clusters
_Last updated: 2025-08-18 • Status: draft • Owner: Max (PO) / Claude Code (Engineer)_

**Purpose**  
Why this table exists and who consumes it.

**Primary key**  
- ...

**Columns**  
- `column_name` (type, null?) — meaning; example

**Indexes / constraints**  
- ...

**Write paths**  
- Which modules insert/update here.

**Read paths**  
- Which modules query this table.

**Data quality**  
- Invariants and validation checks.
