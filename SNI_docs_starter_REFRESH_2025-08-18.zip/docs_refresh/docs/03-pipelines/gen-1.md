# GEN-1 — Narrative Builder

_Last updated: 2025-08-18 • Status: draft • Owner: Max (PO) / Claude Code (Engineer) • Repo: SNI_

Turn clusters into narrative JSON.
