# CLUST-1 — Thematic Grouping (Lexical + Entities)

_Last updated: 2025-08-18 • Status: draft • Owner: Max (PO) / Claude Code (Engineer) • Repo: SNI_

Goal: prevent hub mixing via lexical/entity buckets.
