# Thresholds & Config Knobs

_Last updated: 2025-08-18 • Status: draft • Owner: Max (PO) / Claude Code (Engineer) • Repo: SNI_

- Time window: 48h; Min size: 3; DBSCAN eps=0.30, min_samples=3; Merge cos≥0.85.
